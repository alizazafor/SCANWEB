# Welcome to the Sensei LMS Plugin Hook Documentation

This resource is generated documentation on actions and filters found in the Sensei LMS plugin. You can use the sidebar to browse and navigate.

For more information about Sensei LMS, please visit the [website](https://senseilms.com/).

To report an issue with Sensei LMS or contribute back to the project, please visit the [GitHub repository](https://github.com/automattic/sensei).
