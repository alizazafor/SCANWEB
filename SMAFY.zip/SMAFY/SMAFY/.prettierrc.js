module.exports = {
	...require( '@wordpress/prettier-config' ),
	plugins: [ './scripts/prettier/prettier-plugin-jsdoc' ],
};
