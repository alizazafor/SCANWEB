/**
 * Internal dependencies
 */
import registerSenseiBlocks from '../register-sensei-blocks';
import corePatternPolyfill from './index';

registerSenseiBlocks( [ corePatternPolyfill ] );
