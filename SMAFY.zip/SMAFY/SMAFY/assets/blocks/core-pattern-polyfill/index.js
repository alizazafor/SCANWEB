/**
 * Internal dependencies
 */
import metadata from './block.json';
import edit from './edit';

export default {
	...metadata,
	metadata,
	edit,
};
