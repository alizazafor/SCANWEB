This was borrowed from https://github.com/WordPress/gutenberg/tree/v13.4.0/packages/block-library/src/pattern/
to be used as a polyfill. So it's just registered if Gutenberg didn't register it.
