/**
 * Internal dependencies
 */
import icon from '../../icons/progress.svg';
import edit from './course-progress-edit';
import metadata from './block.json';

export default {
	...metadata,
	metadata,
	icon,
	edit,
};
