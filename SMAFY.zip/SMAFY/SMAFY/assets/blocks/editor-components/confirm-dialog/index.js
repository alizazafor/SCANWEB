/**
 * Internal dependencies
 */
export { default as ConfirmDialog } from './confirm-dialog';
export { default as useConfirmDialogProps } from './use-confirm-dialog-props';
