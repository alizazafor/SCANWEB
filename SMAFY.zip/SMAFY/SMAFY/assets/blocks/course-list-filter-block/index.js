/**
 * Internal dependencies
 */
import icon from '../../icons/course-list-filter.svg';
import metadata from './block.json';
import edit from './course-list-filter-edit';

export default {
	...metadata,
	metadata,
	icon,
	edit,
};
