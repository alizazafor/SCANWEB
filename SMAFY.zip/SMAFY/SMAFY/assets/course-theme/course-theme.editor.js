/**
 * Internal dependencies
 */
import './supports-color';
import './styles-probe';
